Note: IseCreamBasic is derived from "PowerShell ISE-Cream" http://psisecream.codeplex.com/
The module is redistributed according to the license terms as noted in license.txt
