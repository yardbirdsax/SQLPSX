Note: WPK is derived from "PowerShellPack" http://code.msdn.microsoft.com/PowerShellPack
The module is redistributed according to the license terms as noted in license.txt
